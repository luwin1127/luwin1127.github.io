function [U, D] = UD_update(U, D, Phi, Gamma, Q, H, R, TM)
    n = length(U);
    if ~isempty(strfind(upper(TM), 'T'))                % Thornton�㷨��UDʱ�����
        W = [Phi * U, Gamma]; D1 = [D;Q];               % D��Ϊ����
        for j = n : -1 : 1
            D(j) = (W(j,:) .* W(j,:)) * D1;
            for i = 1 : (j - 1)
                U(i, j) = (W(i, :) .* W(j, :)) * D1 / D(j);
                W(i, :) = W(i, :) - U(i, j) * W(j, :);
            end
        end
    end
    if ~isempty(strfind(upper(TM),'M'))                 % Bierman�㷨��UD�������
        f = (H * U)';  g = D .* f;  afa = f' * g + R;
        for j = n : -1 : 1   % �������
            afa0 = afa - f(j) * g(j); lambda = -f(j) / afa0;
            D(j) = afa0 / afa * D(j);   afa = afa0;
            for i= (j-1) : -1 : 1
                s = (i+1) : (j-1);
                U(i,j) = U(i,j) + lambda * (g(i) + U(i, s) * g(s));
            end
        end
    end   
end