这个压缩包里的MATLAB代码是以下五篇文章对应的代码。

[GPOPS-II教程(1): 语法和一个最优控制问题案例](https://leilie.top/2024-06-20/Study-GPOPS-II-guidance-1)

[GPOPS-II教程(2): 可复用火箭再入大气层最优轨迹规划问题](https://leilie.top/2024-06-22/Study-GPOPS-II-guidance-2)

[GPOPS-II教程(3): 航天器最优控制问题](https://leilie.top/2024-06-23/Study-GPOPS-II-guidance-3)

[GPOPS-II教程(4): 多级火箭上升最优控制问题](https://leilie.top/2024-06-26/Study-GPOPS-II-guidance-4)

[GPOPS-II教程(5): 月球探测器着陆最优控制问题]()(https://leilie.top/2024-06-27/Study-GPOPS-II-guidance-5)