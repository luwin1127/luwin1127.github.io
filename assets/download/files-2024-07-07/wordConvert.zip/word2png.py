import fitz  # PyMuPDF  
  
pdf_file = "D://opps//Desktop//test.pdf"  
  
# 打开 PDF 文件  
doc = fitz.open(pdf_file)  
  
# 遍历每一页并保存为图片  
for page_num in range(len(doc)):  
    page = doc[page_num]  
    pix = page.get_pixmap(matrix=fitz.Matrix(2.0, 2.0), alpha=False)
    output = f"page_{page_num + 1}.jpg"  
    pix.save(output)  
    print(f"Saved {output}")  
  
# 关闭 PDF 文件  
doc.close()