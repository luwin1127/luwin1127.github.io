import os
import fitz  # PyMuPDF 
from win32com import client

# 转换doc为pdf
def doc2pdf(word_path, file_path):  
    # 检查 PDF 文件是否存在，如果存在则删除  
    if os.path.exists(file_path):  
        os.remove(file_path)  
        print(f"Deleted existing PDF file: {file_path}")  
      
    word = client.Dispatch("Word.Application")  # 打开word应用程序  
    doc = word.Documents.Open(word_path)        # 打开word文件  
    doc.SaveAs(file_path, 17)                   # 另存为后缀为".pdf"的文件，其中参数17表示为pdf，保存到pdf文件夹
    doc.Close()                                 # 关闭原来word文件  
    word.Quit()
    print(f"Saved {file_path}")  


# 转换docx为pdf
def docx2pdf(word_path, file_path):      
    # 检查 PDF 文件是否存在，如果存在则删除  
    if os.path.exists(file_path):  
        os.remove(file_path)
        print(f"Deleted existing PDF file: {file_path}")  
      
    word = client.Dispatch("Word.Application")  # 打开word应用程序  
    doc = word.Documents.Open(word_path)        # 打开word文件  
    doc.SaveAs(file_path, 17)                   # 另存为后缀为".pdf"的文件，其中参数17表示为pdf，保存到pdf文件夹
    doc.Close()                                 # 关闭原来word文件  
    word.Quit() 
    print(f"Saved {file_path}")  

def pdf2png(pdf_name, pdf_path, png_path):
    # 打开 PDF 文件  
    doc = fitz.open(pdf_path) 
    pdf_name_temp = "{}".format(pdf_name[:-4]) 
    
    # 遍历每一页并保存为图片  
    for page_num in range(len(doc)):  
        page = doc[page_num]  
        pix = page.get_pixmap(matrix=fitz.Matrix(2.0, 2.0), alpha=False)    # pdf 转换 png
        output = f"{png_path}/{pdf_name_temp}_page_{page_num + 1}.png"      # 指定保存名称和保存位置
        pix.save(output)                        # 保存到png文件夹
        print(f"Saved {output}")  
    
    # 关闭 PDF 文件  
    doc.close()

if __name__ == '__main__':
    # 指定文件路径
    current_path = os.getcwd()
    current_word_path = current_path + '/word'

    # 列出当前目录下的所有文件和文件夹  
    # for item in os.listdir(current_word_path):  
    #     print(item) 
    # 如果要改的话，把下面的代码放在这个循环里面，word_name代替item

    # 指定文件名称
    word_name = "test.docx"
    pdf_name = "test.pdf"
    # 将路径合并
    word_file = current_path + '/word/' + word_name
    pdf_file = current_path + '/pdf/' + pdf_name
    png_file = current_path + '/png'
    # word 转 pdf
    docx2pdf(word_file, pdf_file)
    # pdf 转 png
    pdf2png(pdf_name, pdf_file, png_file)