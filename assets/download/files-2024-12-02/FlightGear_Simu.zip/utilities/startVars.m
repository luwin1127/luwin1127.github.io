%% startVars.m - Validate Stateflow License

%   Copyright 2014-2018 The MathWorks, Inc.

% Depending on whether or not Stateflow is installed and a license is
% available, the corresponding Fault Detection variant is selected.
sfDictionaryObj = Simulink.data.dictionary.open('asbhl20_FDIRAppData.sldd');
sfDataSectObj = getSection(sfDictionaryObj,'Design Data');
if evalin(sfDataSectObj, 'VSS_MODELLOGIC') == 1 && ...
    ~builtin('license','test','Stateflow')
        evalin(sfDataSectObj,'VSS_MODELLOGIC = 0;');
else
    close(sfDictionaryObj);
end

clear sfDictionaryObj sfDataSectObj
