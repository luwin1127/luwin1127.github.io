function asbSetGRT
% ASBSETGRT This utility sets the HL20 project system target to GRT

% Copyright 2016-2017 The MathWorks, Inc.

% Model Reference models
modelrefName =  {...
    'asbhl20_FDIRApp',...
    'asbhl20_FCSApp',...
    'asbhl20_GuidanceApp',...
    'asbhl20_FDIRmodelogicApp',...
    'asbhl20_VehicleSystemsModel'};

% Set model reference build targets to GRT if not already set
for k=1:length(modelrefName)
    load_system(modelrefName{k});
    if strcmp(get_param(modelrefName{k},'SystemTargetFile'),'grt.tlc')
        fprintf('Build target for Model Reference %s is set to GRT.\n',...
            modelrefName{k});
    else
        fprintf('Setting build target for Model Reference %s to GRT.....',...
            modelrefName{k});
        set_param(modelrefName{k},'SystemTargetFile','grt.tlc');
        save_system(modelrefName{k});
        fprintf('Done\n');
    end
    close_system(modelrefName{k});
end

% Build HL20 for GRT
modelname = 'asbhl20';
open_system(modelname);
if strcmp(get_param(modelname,'SystemTargetFile'),'grt.tlc')
    fprintf('Build target for Model %s is set to GRT.\n',...
        modelname);
else
    fprintf('Setting build target for Model %s to GRT.....',...
        modelname);
    set_param(modelname,'SystemTargetFile','grt.tlc');
    save_system(modelname);
    fprintf('Done\n');
end
msgbox('The HL20 example is now set up for GRT', 'asbSetGRT');