%% Running HL-20 Vehicle Simulation in Parallel using Parsim
% This example shows how to run the Aerospace Blockset HL-20 simulation
% using the parsim command to observe the effects of wind gust amplitude
% changes and actuator failures on the stability of the vehicle model. If
% the Parallel Computing Toolbox is installed, the simulations run in
% parallel. If the Parallel Computing Toolbox is not installed, the
% simulations run in serial.

%%
% Copyright 2017-2018 The MathWorks, Inc.

function out = asbPARSIM()

%% Prepare Model for Parallel Simulations
% Turn on signal logging for the body angular rates of the vehicle.  This
% logged signal is used in the analysis of the simulation results.

modelname = 'asbhl20_parallelSim';
vehiclename = 'asbhl20_VehicleSystemsModel';

% Open top level model.
open_system(modelname);
% Load referenced vehicle model to change the signal logging settings.
load_system(vehiclename); 

% Turn signal logging on in top level model.
set_param(modelname,'SignalLogging','on') 
% Full simulation is unnecessary to observe desired behavior.
set_param(modelname,'StopTime','40')
% Log body angular rates.
ph = get_param([vehiclename '/Vehicle/6DOF ECEF (Quaternion)'],'PortHandles');
set_param(ph.Outport(10),'DataLogging','on'); 

save_system(vehiclename);
save_system(modelname);

%% Verify that mode logic variant subsystem is set to use Stateflow chart
% Subsystem 'asbhl20_FDIRApp/Mode Logic for Wing, Upper, and Lower/Variant
% Subsystem' must be set to VSS_MODELLOGIC_APP in order to model actuator
% failures.
if builtin('license','test','Stateflow')
    sfDictionaryObj = Simulink.data.dictionary.open('asbhl20_FDIRAppData.sldd');
    sfDataSectObj = getSection(sfDictionaryObj,'Design Data');
    if evalin(sfDataSectObj, 'VSS_MODELLOGIC') ~= 1
        evalin(sfDataSectObj,'VSS_MODELLOGIC = 1;');
    end       
else
    warning(message('aeroblks_demos_hl20:asbhl20:NoStateflowLicense'));
end

%% Define Suite of Varying Wind Gust Amplitudes and Actuator Failures
% Identify which actuators to fail and what range of wind gust amplitudes
% to run for each failed actuator case. This suite of failure scenarios is
% captured as an array of Simulink.SimulationInput objects, which is an
% input to the parsim command.

% Define the range of the parameter sweep used to vary wind gust amplitudes
% in asbhl20_parallelSim/Environment. This example increases wind gusts up
% to 12 m/s beyond a default value [10.0 34.0 3.0] in the positive v-axis
% of the body frame. Gusts are introduced at t = 20 sec.
gust_default = [10.0 34.0 3.0];
gust_vg = gust_default(2) : 2 : gust_default(2) + 12;
gust_ug = gust_default(1)*ones(size(gust_vg));
gust_wg = gust_default(3)*ones(size(gust_vg));
gust_amp = [gust_ug' gust_vg' gust_wg'];

% Access the bus object in Simulink that represents the actuator failures
% in the simulation.  Create a MATLAB structure from the bus object using
% the command Simulink.Bus.createMATLABStruct(). This object specifies
% which actuators have failures during simulation.
ActuatorStatus_default = Simulink.Bus.createMATLABStruct('InsertFailureBus',...
    [],1,Simulink.data.DataDictionary('asbhl20Data.sldd'));

% Choose the combination of actuators to fail in each simulation run. For
% this example, fail the left upper flap (LU1 and LU2), the right upper
% flap (RU1 and RU2), the left wing aileron (WL1 and WL2), and the right
% wing aileron (WR1 and WR2).
ActuatorsToTest = {{'LU1','LU2'},... % Left upper flap
                   {'RU1','RU2'},... % Right upper flap
                   {'WL1','WL2'},... % Left wing aileron
                   {'WR1','WR2'}};   % Right wing aileron

% Get the time scale from the model to use in creating timeseries data for
% the actuator failures.
t = eval(get_param(modelname,'StartTime')) : ...
    eval(get_param(modelname,'FixedStep')) : ...
    eval(get_param(modelname,'StopTime'));

% Use for loops to create a Simulink.SimulationInput object for each
% combination of wind gust amplitudes and actuator failures to be run.
% This example contains 7 different gust amplitude cases for each of the 4
% actuator failure cases. Including the baseline case with no actuator
% failures, a total of 35 runs are distributed across the default pool of
% workers.
ldx = 0;

% For each actuator failure scenario:
for idx = 0:numel(ActuatorsToTest) 
    % Reset actuator status to default (all off).
    ActuatorStatus = ActuatorStatus_default;

    % Always run no-failure case first as baseline.
    if idx ~= 0
        multipleActFailures = iscell(ActuatorsToTest{idx});
        if multipleActFailures
            for jdx = 1 : numel(ActuatorsToTest{idx})
                % Enable failure for desired actuator.
                ActuatorStatus.(ActuatorsToTest{idx}{jdx}) = 1; 
            end
        else
            ActuatorStatus.(ActuatorsToTest{idx}) = 1;
        end
    end
    
    % Create timeseries for actuator failure statuses.
    ActuatorInput = structfun(@(x) timeseries(repmat(x,size(t)),t),...
        ActuatorStatus, 'UniformOutput', false); 
    
    % For each set of gust amplitudes:
    for kdx = 1:size(gust_amp,1) %#ok<*AGROW> 
        ldx = ldx + 1;
        
        % Create Simulink.SimulationInput object for model.
        simIn(ldx) = Simulink.SimulationInput(modelname);
        % Actuator failures will be inserted via a root inport.
        simIn(ldx).ExternalInput = ActuatorInput;
        % Wind gust will be modified in the block parameters page.
        simIn(ldx) = simIn(ldx).setBlockParameter(...
            [modelname '/Environment'],...
            'gust_v_m', sprintf('[%.1f %.1f %.1f]',gust_amp(kdx,:)));
        
        try
            if multipleActFailures
                % Record current failed actuator settings.
                diagnostics(ldx).ActFailed = strjoin(ActuatorsToTest{idx});
            else
                diagnostics(ldx).ActFailed = sprintf(ActuatorsToTest{idx});
            end  
        catch
            diagnostics(ldx).ActFailed = 'None';
        end
        
        % Record current wind gust settings.
        diagnostics(ldx).GustAmp = gust_amp(kdx,:); 
    end
end

%% Run Simulations in Parallel
% Distribute the 35 scenarios among the workers of the default parallel
% pool. Upon completion, results are saved to an output array.

out = parsim(simIn, 'ShowProgress','on', 'UseFastRestart', 'on');

%% Plot Simulation Results
% Plot the results of the simulation runs.  To see how each actuator
% failure effects the overall stability of the vehicle, compare the
% vehicle's angular rates for each failed actuator case at each wind gust
% interval.  In the plots, observe instability in cases where the angular
% rates do not recover in all axes after the gust is applied at t = 20 sec.

% Get body angular rates (rad/s) from logged signal output.
omega_b_wrtECI_b = arrayfun(@(x) getElement(x.sigsOut, 'pqr'), out); 

axislabel = {'U', 'V', 'W'};
for idx = 1:size(gust_amp,1)
    jdx = idx;
     
    fig = figure('Name', sprintf(['HL-20 Failure Analysis: Angular Rate',...
        ' of Body with Wind Gust = [%d %d %d] m/s'], diagnostics(jdx).GustAmp(1),...
        diagnostics(jdx).GustAmp(2), diagnostics(jdx).GustAmp(3)));
    fig.IntegerHandle = 'off';
    
    % Prepare plots.
    axHdl(1) = subplot(3,1,1); hold on; legend('Location', 'eastoutside'); 
    axHdl(2) = subplot(3,1,2); hold on; legend('Location', 'eastoutside');
    axHdl(3) = subplot(3,1,3); hold on; legend('Location', 'eastoutside');
    
    % For each failed actuator case (including none):
    for ldx = 1:numel(ActuatorsToTest)+1
        
        % For each body axis:
        for kdx = 1:3 
            
            plot(axHdl(kdx), omega_b_wrtECI_b(jdx).Values.Time, ...
                omega_b_wrtECI_b(jdx).Values.Data(:,kdx),...
                'DisplayName', sprintf('Failed Actuators: %s',...
                diagnostics(jdx).ActFailed));
            
            title(axHdl(kdx), sprintf(['Angular Rate of Body in %s ',...
                'direction, Gust: [%d %d %d] m/s'],...
                axislabel{kdx}, diagnostics(jdx).GustAmp(1),...
                diagnostics(jdx).GustAmp(2), diagnostics(jdx).GustAmp(3)));
            xlabel(axHdl(kdx), 'Time (s)');
            ylabel(axHdl(kdx), 'Angular Rate (rad/s)');
            xlim(axHdl(kdx),[0,40]);
        end
        
        % Increment to index of next desired run.
        jdx = jdx + size(omega_b_wrtECI_b(:),1)/(numel(ActuatorsToTest)+1); 
    end
    
    hold off;   
end

% To examine specific scenarios, use the asbhl20 model. Insert actuator
% failures into the model in asbhl20/Actuator System Failures and change
% wind gust amplitudes in asbhl20/Environment. To visualize unstable
% scenarios, connect to FlightGear.
end
