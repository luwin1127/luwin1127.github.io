#include "__cf_asbhl20_FDIRmodelogicApp.h"
#ifndef RTW_HEADER_asbhl20_FDIRmodelogicApp_h_
#define RTW_HEADER_asbhl20_FDIRmodelogicApp_h_
#include <string.h>
#include <stddef.h>
#include "rtw_modelmap.h"
#ifndef asbhl20_FDIRmodelogicApp_COMMON_INCLUDES_
#define asbhl20_FDIRmodelogicApp_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "slsv_diagnostic_codegen_c_api.h"
#include "simstruc.h"
#include "fixedpoint.h"
#include "sf_runtime/sfc_sdi.h"
#endif
#include "asbhl20_FDIRmodelogicApp_types.h"
#include "multiword_types.h"
#include "rt_nonfinite.h"
typedef struct { real_T kiqkxaskny ; real_T jrsv2du3ux ; real_T ie42kl3foi ;
real_T lsyrrqyfc3 ; real_T luwfne0fze ; real_T p0zzmfdw2s ; real_T hxentl1cgi
; real_T kuwjtglrmc ; int32_T erd0rz1uuq ; int32_T j2mrqjospj ; int32_T
cwczkfsfwo ; int32_T e5rzcmrkza ; uint8_T ase32ysxwz ; uint8_T oyi3pbwxsi ;
uint8_T ji3tc4mchm ; uint8_T byk4it4mn4 ; uint8_T juzg2wjpep ; uint8_T
jxafxk4oqz ; uint8_T cbw25uwmwe ; uint8_T hbaqu3tjvl ; uint8_T mpaxivywwh ; }
ib3bykxihl ; struct kfm4wy3c3c { struct SimStruct_tag * _mdlRefSfcnS ; struct
{ rtwCAPI_ModelMappingInfo mmi ; rtwCAPI_ModelMapLoggingInstanceInfo
mmiLogInstanceInfo ; sysRanDType * systemRan [ 3 ] ; int_T systemTid [ 3 ] ;
} DataMapInfo ; struct { int_T mdlref_GlobalTID [ 1 ] ; } Timing ; } ;
typedef struct { ib3bykxihl rtdw ; erjgiscrq5 rtm ; } apfjvdlacsv ; extern
void o0xknv4kz2 ( SimStruct * _mdlRefSfcnS , int_T mdlref_TID0 , erjgiscrq5 *
const jak0do2ew0 , ib3bykxihl * localDW , void * sysRanPtr , int contextTid ,
rtwCAPI_ModelMappingInfo * rt_ParentMMI , const char_T * rt_ChildPath , int_T
rt_ChildMMIIdx , int_T rt_CSTATEIdx ) ; extern void
mr_asbhl20_FDIRmodelogicApp_MdlInfoRegFcn ( SimStruct * mdlRefSfcnS , char_T
* modelName , int_T * retVal ) ; extern mxArray *
mr_asbhl20_FDIRmodelogicApp_GetDWork ( const apfjvdlacsv * mdlrefDW ) ;
extern void mr_asbhl20_FDIRmodelogicApp_SetDWork ( apfjvdlacsv * mdlrefDW ,
const mxArray * ssDW ) ; extern void
mr_asbhl20_FDIRmodelogicApp_RegisterSimStateChecksum ( SimStruct * S ) ;
extern mxArray * mr_asbhl20_FDIRmodelogicApp_GetSimStateDisallowedBlocks ( )
; extern const rtwCAPI_ModelMappingStaticInfo *
asbhl20_FDIRmodelogicApp_GetCAPIStaticMap ( void ) ; extern void i2odqztc0a (
int8_T * meckanrj2q , int8_T * cpv2jbmc33 , int8_T * jx1kwzmku0 , int8_T *
izoy0sdbwz , ib3bykxihl * localDW ) ; extern void p3royrfzsq ( int8_T *
meckanrj2q , int8_T * cpv2jbmc33 , int8_T * jx1kwzmku0 , int8_T * izoy0sdbwz
, ib3bykxihl * localDW ) ; extern void asbhl20_FDIRmodelogicApp ( const
boolean_T hzccke5rmp [ 3 ] , const boolean_T pfntoy3xkz [ 2 ] , const
boolean_T hp0wqb1p3i [ 2 ] , int8_T * meckanrj2q , int8_T * cpv2jbmc33 ,
int8_T * jx1kwzmku0 , int8_T * izoy0sdbwz , ib3bykxihl * localDW ) ; extern
void coixd5oata ( erjgiscrq5 * const jak0do2ew0 ) ;
#endif
