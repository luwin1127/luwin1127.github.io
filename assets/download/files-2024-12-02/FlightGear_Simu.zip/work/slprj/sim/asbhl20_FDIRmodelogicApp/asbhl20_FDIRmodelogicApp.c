#include "__cf_asbhl20_FDIRmodelogicApp.h"
#include "asbhl20_FDIRmodelogicApp_capi.h"
#include "asbhl20_FDIRmodelogicApp.h"
#include "asbhl20_FDIRmodelogicApp_private.h"
#define abe01fyzks ((uint8_T)0U)
#define aqn4kquuru ((uint8_T)1U)
#define cv4vbtpbn3 ((uint8_T)3U)
#define dctdxp1phd ((uint8_T)1U)
#define h1wbaxl2ex ((uint8_T)4U)
#define hat1yso11f ((uint8_T)2U)
#define m5cz4wjk5r ((uint8_T)2U)
static RegMdlInfo rtMdlInfo_asbhl20_FDIRmodelogicApp [ 44 ] = { {
"apfjvdlacsv" , MDL_INFO_NAME_MDLREF_DWORK , 0 , - 1 , ( void * )
"asbhl20_FDIRmodelogicApp" } , { "dbflhfj3lr" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"asbhl20_FDIRmodelogicApp" } , { "k1fmcv1ntb" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"asbhl20_FDIRmodelogicApp" } , { "lppo143fm2" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"asbhl20_FDIRmodelogicApp" } , { "h4o2mcqk3d" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"asbhl20_FDIRmodelogicApp" } , { "kv0knjmoef" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"asbhl20_FDIRmodelogicApp" } , { "ghitlvoes4" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"asbhl20_FDIRmodelogicApp" } , { "i0rmgneueo" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"asbhl20_FDIRmodelogicApp" } , { "m4yepqq5xg" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"asbhl20_FDIRmodelogicApp" } , { "edlgo45uht" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"asbhl20_FDIRmodelogicApp" } , { "ib3bykxihl" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"asbhl20_FDIRmodelogicApp" } , { "kmm4kzpum3" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"asbhl20_FDIRmodelogicApp" } , { "gwh14bt44h" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"asbhl20_FDIRmodelogicApp" } , { "coixd5oata" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"asbhl20_FDIRmodelogicApp" } , { "deoxyzwrum" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"asbhl20_FDIRmodelogicApp" } , { "p3royrfzsq" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"asbhl20_FDIRmodelogicApp" } , { "i2odqztc0a" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"asbhl20_FDIRmodelogicApp" } , { "o0xknv4kz2" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"asbhl20_FDIRmodelogicApp" } , { "py0tebtrh1" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"asbhl20_FDIRmodelogicApp" } , { "d11qke1ngj" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"asbhl20_FDIRmodelogicApp" } , { "asbhl20_FDIRmodelogicApp" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , 0 , ( NULL ) } , { "nuo2c1alvk0" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"asbhl20_FDIRmodelogicApp" } , { "p54w40mvuba" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"asbhl20_FDIRmodelogicApp" } , { "ezzxp4elbu" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"asbhl20_FDIRmodelogicApp" } , { "o4l3i1clpap" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"asbhl20_FDIRmodelogicApp" } , { "d0qq4l0ectw" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"asbhl20_FDIRmodelogicApp" } , { "nuo2c1alvk" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"asbhl20_FDIRmodelogicApp" } , { "p54w40mvub" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"asbhl20_FDIRmodelogicApp" } , { "kfm4wy3c3c" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"asbhl20_FDIRmodelogicApp" } , { "erjgiscrq5" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"asbhl20_FDIRmodelogicApp" } , {
"mr_asbhl20_FDIRmodelogicApp_GetSimStateDisallowedBlocks" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "asbhl20_FDIRmodelogicApp"
} , { "mr_asbhl20_FDIRmodelogicApp_extractBitFieldFromCellArrayWithOffset" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "asbhl20_FDIRmodelogicApp"
} , { "mr_asbhl20_FDIRmodelogicApp_cacheBitFieldToCellArrayWithOffset" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "asbhl20_FDIRmodelogicApp"
} , { "mr_asbhl20_FDIRmodelogicApp_restoreDataFromMxArrayWithOffset" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "asbhl20_FDIRmodelogicApp"
} , { "mr_asbhl20_FDIRmodelogicApp_cacheDataToMxArrayWithOffset" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "asbhl20_FDIRmodelogicApp"
} , { "mr_asbhl20_FDIRmodelogicApp_extractBitFieldFromMxArray" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "asbhl20_FDIRmodelogicApp"
} , { "mr_asbhl20_FDIRmodelogicApp_cacheBitFieldToMxArray" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "asbhl20_FDIRmodelogicApp"
} , { "mr_asbhl20_FDIRmodelogicApp_restoreDataFromMxArray" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "asbhl20_FDIRmodelogicApp"
} , { "mr_asbhl20_FDIRmodelogicApp_cacheDataAsMxArray" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "asbhl20_FDIRmodelogicApp"
} , { "mr_asbhl20_FDIRmodelogicApp_RegisterSimStateChecksum" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "asbhl20_FDIRmodelogicApp"
} , { "mr_asbhl20_FDIRmodelogicApp_SetDWork" , MDL_INFO_ID_MODEL_FCN_NAME , 0
, - 1 , ( void * ) "asbhl20_FDIRmodelogicApp" } , {
"mr_asbhl20_FDIRmodelogicApp_GetDWork" , MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1
, ( void * ) "asbhl20_FDIRmodelogicApp" } , { "asbhl20_FDIRmodelogicApp.h" ,
MDL_INFO_MODEL_FILENAME , 0 , - 1 , ( NULL ) } , {
"asbhl20_FDIRmodelogicApp.c" , MDL_INFO_MODEL_FILENAME , 0 , - 1 , ( void * )
"asbhl20_FDIRmodelogicApp" } } ; static void ahth4hcu5q ( const boolean_T
hzccke5rmp [ 3 ] , const boolean_T hp0wqb1p3i [ 2 ] , ib3bykxihl * localDW )
; static void p12kfhtpp2 ( const boolean_T hzccke5rmp [ 3 ] , const boolean_T
pfntoy3xkz [ 2 ] , ib3bykxihl * localDW ) ; static real_T b15g510lmm (
ib3bykxihl * localDW ) ; static real_T lfbpfq3smd ( ib3bykxihl * localDW ) ;
static void ojqiuzhc0b ( const boolean_T hzccke5rmp [ 3 ] , int8_T *
meckanrj2q , ib3bykxihl * localDW ) ; static real_T nbfoxc4li0 ( ib3bykxihl *
localDW ) ; static real_T gjvzuvr4ls ( ib3bykxihl * localDW ) ; static void
celbwo0ozv ( const boolean_T hzccke5rmp [ 3 ] , const boolean_T pfntoy3xkz [
2 ] , const boolean_T hp0wqb1p3i [ 2 ] , int8_T * meckanrj2q , int8_T *
cpv2jbmc33 , int8_T * jx1kwzmku0 , int8_T * izoy0sdbwz , ib3bykxihl * localDW
) ; static void ahth4hcu5q ( const boolean_T hzccke5rmp [ 3 ] , const
boolean_T hp0wqb1p3i [ 2 ] , ib3bykxihl * localDW ) { boolean_T tmp ;
boolean_T tmp_p ; tmp = ! hzccke5rmp [ 1 ] ; tmp_p = ! hp0wqb1p3i [ 1 ] ; if
( hzccke5rmp [ 0 ] && tmp && tmp_p ) { localDW -> p0zzmfdw2s = 1.0 ; } else
if ( hzccke5rmp [ 0 ] ) { localDW -> jrsv2du3ux = 1.0 ; localDW -> kiqkxaskny
= 1.0 ; } else if ( ( ! hzccke5rmp [ 0 ] ) && hp0wqb1p3i [ 0 ] && tmp &&
tmp_p ) { localDW -> jrsv2du3ux = 1.0 ; } else if ( ( ! hzccke5rmp [ 0 ] ) &&
hp0wqb1p3i [ 0 ] ) { localDW -> jrsv2du3ux = 1.0 ; localDW -> kiqkxaskny =
1.0 ; } else if ( hzccke5rmp [ 1 ] ) { localDW -> luwfne0fze = 1.0 ; } else {
if ( hp0wqb1p3i [ 1 ] ) { localDW -> kiqkxaskny = 1.0 ; } } } static void
p12kfhtpp2 ( const boolean_T hzccke5rmp [ 3 ] , const boolean_T pfntoy3xkz [
2 ] , ib3bykxihl * localDW ) { boolean_T tmp ; boolean_T tmp_p ; tmp = !
hzccke5rmp [ 1 ] ; tmp_p = ! pfntoy3xkz [ 1 ] ; if ( hzccke5rmp [ 2 ] && tmp
&& tmp_p ) { localDW -> kuwjtglrmc = 1.0 ; } else if ( hzccke5rmp [ 2 ] ) {
localDW -> lsyrrqyfc3 = 1.0 ; localDW -> ie42kl3foi = 1.0 ; } else if ( ( !
hzccke5rmp [ 2 ] ) && pfntoy3xkz [ 0 ] && tmp && tmp_p ) { localDW ->
lsyrrqyfc3 = 1.0 ; } else if ( ( ! hzccke5rmp [ 2 ] ) && pfntoy3xkz [ 0 ] ) {
localDW -> lsyrrqyfc3 = 1.0 ; localDW -> ie42kl3foi = 1.0 ; } else if (
hzccke5rmp [ 1 ] ) { localDW -> hxentl1cgi = 1.0 ; } else { if ( pfntoy3xkz [
1 ] ) { localDW -> ie42kl3foi = 1.0 ; } } } static real_T b15g510lmm (
ib3bykxihl * localDW ) { return localDW -> cbw25uwmwe == aqn4kquuru ; }
static real_T lfbpfq3smd ( ib3bykxihl * localDW ) { return localDW ->
juzg2wjpep == aqn4kquuru ; } static void ojqiuzhc0b ( const boolean_T
hzccke5rmp [ 3 ] , int8_T * meckanrj2q , ib3bykxihl * localDW ) { if (
localDW -> oyi3pbwxsi == dctdxp1phd ) { if ( localDW -> jrsv2du3ux != 0.0 ) {
if ( localDW -> ji3tc4mchm == hat1yso11f ) { localDW -> erd0rz1uuq ++ ;
localDW -> ji3tc4mchm = abe01fyzks ; } else { localDW -> ji3tc4mchm =
abe01fyzks ; } localDW -> oyi3pbwxsi = m5cz4wjk5r ; * meckanrj2q = 0 ; } else
if ( ( localDW -> p0zzmfdw2s != 0.0 ) && ( localDW -> ji3tc4mchm !=
hat1yso11f ) ) { if ( localDW -> erd0rz1uuq >= 5 ) { if ( localDW ->
ji3tc4mchm == hat1yso11f ) { localDW -> erd0rz1uuq ++ ; localDW -> ji3tc4mchm
= abe01fyzks ; } else { localDW -> ji3tc4mchm = abe01fyzks ; } localDW ->
oyi3pbwxsi = m5cz4wjk5r ; * meckanrj2q = 0 ; } else { if ( localDW ->
ji3tc4mchm == hat1yso11f ) { localDW -> erd0rz1uuq ++ ; localDW -> ji3tc4mchm
= abe01fyzks ; } else { localDW -> ji3tc4mchm = abe01fyzks ; } localDW ->
ji3tc4mchm = hat1yso11f ; * meckanrj2q = 1 ; } } else { switch ( localDW ->
ji3tc4mchm ) { case aqn4kquuru : * meckanrj2q = 4 ; if ( ( ! ( lfbpfq3smd (
localDW ) != 0.0 ) ) && ( b15g510lmm ( localDW ) != 0.0 ) ) { localDW ->
ji3tc4mchm = h1wbaxl2ex ; * meckanrj2q = 3 ; } break ; case hat1yso11f : *
meckanrj2q = 1 ; if ( ! hzccke5rmp [ 0 ] ) { localDW -> p0zzmfdw2s = 0.0 ;
localDW -> erd0rz1uuq ++ ; localDW -> ji3tc4mchm = cv4vbtpbn3 ; * meckanrj2q
= 2 ; } break ; case cv4vbtpbn3 : * meckanrj2q = 2 ; if ( b15g510lmm (
localDW ) != 0.0 ) { localDW -> ji3tc4mchm = h1wbaxl2ex ; * meckanrj2q = 3 ;
} else { if ( ( ! ( b15g510lmm ( localDW ) != 0.0 ) ) || ( lfbpfq3smd (
localDW ) != 0.0 ) ) { localDW -> ji3tc4mchm = aqn4kquuru ; * meckanrj2q = 4
; } } break ; default : * meckanrj2q = 3 ; if ( ( ! ( b15g510lmm ( localDW )
!= 0.0 ) ) || ( lfbpfq3smd ( localDW ) != 0.0 ) ) { localDW -> ji3tc4mchm =
aqn4kquuru ; * meckanrj2q = 4 ; } break ; } } } else { * meckanrj2q = 0 ; } }
static real_T nbfoxc4li0 ( ib3bykxihl * localDW ) { return localDW ->
mpaxivywwh == aqn4kquuru ; } static real_T gjvzuvr4ls ( ib3bykxihl * localDW
) { return localDW -> ji3tc4mchm == aqn4kquuru ; } static void celbwo0ozv (
const boolean_T hzccke5rmp [ 3 ] , const boolean_T pfntoy3xkz [ 2 ] , const
boolean_T hp0wqb1p3i [ 2 ] , int8_T * meckanrj2q , int8_T * cpv2jbmc33 ,
int8_T * jx1kwzmku0 , int8_T * izoy0sdbwz , ib3bykxihl * localDW ) {
ahth4hcu5q ( hzccke5rmp , hp0wqb1p3i , localDW ) ; p12kfhtpp2 ( hzccke5rmp ,
pfntoy3xkz , localDW ) ; ojqiuzhc0b ( hzccke5rmp , meckanrj2q , localDW ) ;
if ( localDW -> byk4it4mn4 == dctdxp1phd ) { if ( localDW -> lsyrrqyfc3 !=
0.0 ) { if ( localDW -> juzg2wjpep == hat1yso11f ) { localDW -> j2mrqjospj ++
; localDW -> juzg2wjpep = abe01fyzks ; } else { localDW -> juzg2wjpep =
abe01fyzks ; } localDW -> byk4it4mn4 = m5cz4wjk5r ; * jx1kwzmku0 = 0 ; } else
if ( ( localDW -> kuwjtglrmc != 0.0 ) && ( localDW -> juzg2wjpep !=
hat1yso11f ) ) { if ( localDW -> j2mrqjospj >= 5 ) { if ( localDW ->
juzg2wjpep == hat1yso11f ) { localDW -> j2mrqjospj ++ ; localDW -> juzg2wjpep
= abe01fyzks ; } else { localDW -> juzg2wjpep = abe01fyzks ; } localDW ->
byk4it4mn4 = m5cz4wjk5r ; * jx1kwzmku0 = 0 ; } else { if ( localDW ->
juzg2wjpep == hat1yso11f ) { localDW -> j2mrqjospj ++ ; localDW -> juzg2wjpep
= abe01fyzks ; } else { localDW -> juzg2wjpep = abe01fyzks ; } localDW ->
juzg2wjpep = hat1yso11f ; * jx1kwzmku0 = 1 ; } } else { switch ( localDW ->
juzg2wjpep ) { case aqn4kquuru : * jx1kwzmku0 = 4 ; if ( ( ! ( gjvzuvr4ls (
localDW ) != 0.0 ) ) && ( nbfoxc4li0 ( localDW ) != 0.0 ) ) { localDW ->
juzg2wjpep = h1wbaxl2ex ; * jx1kwzmku0 = 3 ; } break ; case hat1yso11f : *
jx1kwzmku0 = 1 ; if ( ! hzccke5rmp [ 2 ] ) { localDW -> kuwjtglrmc = 0.0 ;
localDW -> j2mrqjospj ++ ; localDW -> juzg2wjpep = cv4vbtpbn3 ; * jx1kwzmku0
= 2 ; } break ; case cv4vbtpbn3 : * jx1kwzmku0 = 2 ; if ( nbfoxc4li0 (
localDW ) != 0.0 ) { localDW -> juzg2wjpep = h1wbaxl2ex ; * jx1kwzmku0 = 3 ;
} else { if ( ( ! ( nbfoxc4li0 ( localDW ) != 0.0 ) ) || ( gjvzuvr4ls (
localDW ) != 0.0 ) ) { localDW -> juzg2wjpep = aqn4kquuru ; * jx1kwzmku0 = 4
; } } break ; default : * jx1kwzmku0 = 3 ; if ( ( ! ( nbfoxc4li0 ( localDW )
!= 0.0 ) ) || ( gjvzuvr4ls ( localDW ) != 0.0 ) ) { localDW -> juzg2wjpep =
aqn4kquuru ; * jx1kwzmku0 = 4 ; } break ; } } } else { * jx1kwzmku0 = 0 ; }
if ( localDW -> jxafxk4oqz == dctdxp1phd ) { if ( localDW -> kiqkxaskny !=
0.0 ) { if ( localDW -> cbw25uwmwe == hat1yso11f ) { localDW -> cwczkfsfwo ++
; localDW -> cbw25uwmwe = abe01fyzks ; } else { localDW -> cbw25uwmwe =
abe01fyzks ; } localDW -> jxafxk4oqz = m5cz4wjk5r ; * cpv2jbmc33 = 0 ; } else
if ( ( localDW -> luwfne0fze != 0.0 ) && ( localDW -> cbw25uwmwe !=
hat1yso11f ) ) { if ( localDW -> cwczkfsfwo >= 5 ) { if ( localDW ->
cbw25uwmwe == hat1yso11f ) { localDW -> cwczkfsfwo ++ ; localDW -> cbw25uwmwe
= abe01fyzks ; } else { localDW -> cbw25uwmwe = abe01fyzks ; } localDW ->
jxafxk4oqz = m5cz4wjk5r ; * cpv2jbmc33 = 0 ; } else { if ( localDW ->
cbw25uwmwe == hat1yso11f ) { localDW -> cwczkfsfwo ++ ; localDW -> cbw25uwmwe
= abe01fyzks ; } else { localDW -> cbw25uwmwe = abe01fyzks ; } localDW ->
cbw25uwmwe = hat1yso11f ; * cpv2jbmc33 = 1 ; } } else { switch ( localDW ->
cbw25uwmwe ) { case aqn4kquuru : * cpv2jbmc33 = 4 ; if ( ( lfbpfq3smd (
localDW ) != 0.0 ) && ( gjvzuvr4ls ( localDW ) != 0.0 ) ) { localDW ->
cbw25uwmwe = h1wbaxl2ex ; * cpv2jbmc33 = 3 ; } break ; case hat1yso11f : *
cpv2jbmc33 = 1 ; if ( ! hzccke5rmp [ 1 ] ) { localDW -> luwfne0fze = 0.0 ;
localDW -> cwczkfsfwo ++ ; localDW -> cbw25uwmwe = cv4vbtpbn3 ; * cpv2jbmc33
= 2 ; } break ; case cv4vbtpbn3 : * cpv2jbmc33 = 2 ; if ( gjvzuvr4ls (
localDW ) != 0.0 ) { localDW -> cbw25uwmwe = h1wbaxl2ex ; * cpv2jbmc33 = 3 ;
} else { if ( ( ! ( gjvzuvr4ls ( localDW ) != 0.0 ) ) || ( nbfoxc4li0 (
localDW ) != 0.0 ) ) { localDW -> cbw25uwmwe = aqn4kquuru ; * cpv2jbmc33 = 4
; } } break ; default : * cpv2jbmc33 = 3 ; if ( ( ! ( gjvzuvr4ls ( localDW )
!= 0.0 ) ) || ( nbfoxc4li0 ( localDW ) != 0.0 ) ) { localDW -> cbw25uwmwe =
aqn4kquuru ; * cpv2jbmc33 = 4 ; } break ; } } } else { * cpv2jbmc33 = 0 ; }
if ( localDW -> hbaqu3tjvl == dctdxp1phd ) { if ( localDW -> ie42kl3foi !=
0.0 ) { if ( localDW -> mpaxivywwh == hat1yso11f ) { localDW -> e5rzcmrkza ++
; localDW -> mpaxivywwh = abe01fyzks ; } else { localDW -> mpaxivywwh =
abe01fyzks ; } localDW -> hbaqu3tjvl = m5cz4wjk5r ; * izoy0sdbwz = 0 ; } else
if ( ( localDW -> hxentl1cgi != 0.0 ) && ( localDW -> mpaxivywwh ==
hat1yso11f ) ) { if ( localDW -> e5rzcmrkza >= 5 ) { if ( localDW ->
mpaxivywwh == hat1yso11f ) { localDW -> e5rzcmrkza ++ ; localDW -> mpaxivywwh
= abe01fyzks ; } else { localDW -> mpaxivywwh = abe01fyzks ; } localDW ->
hbaqu3tjvl = m5cz4wjk5r ; * izoy0sdbwz = 0 ; } else { if ( localDW ->
mpaxivywwh == hat1yso11f ) { localDW -> e5rzcmrkza ++ ; localDW -> mpaxivywwh
= abe01fyzks ; } else { localDW -> mpaxivywwh = abe01fyzks ; } localDW ->
mpaxivywwh = hat1yso11f ; * izoy0sdbwz = 1 ; } } else { switch ( localDW ->
mpaxivywwh ) { case aqn4kquuru : * izoy0sdbwz = 4 ; if ( ( gjvzuvr4ls (
localDW ) != 0.0 ) && ( lfbpfq3smd ( localDW ) != 0.0 ) ) { localDW ->
mpaxivywwh = h1wbaxl2ex ; * izoy0sdbwz = 3 ; } break ; case hat1yso11f : *
izoy0sdbwz = 1 ; if ( ! hzccke5rmp [ 1 ] ) { localDW -> hxentl1cgi = 0.0 ;
localDW -> e5rzcmrkza ++ ; localDW -> mpaxivywwh = cv4vbtpbn3 ; * izoy0sdbwz
= 2 ; } break ; case cv4vbtpbn3 : * izoy0sdbwz = 2 ; if ( lfbpfq3smd (
localDW ) != 0.0 ) { localDW -> mpaxivywwh = h1wbaxl2ex ; * izoy0sdbwz = 3 ;
} else { if ( ( ! ( lfbpfq3smd ( localDW ) != 0.0 ) ) || ( b15g510lmm (
localDW ) != 0.0 ) ) { localDW -> mpaxivywwh = aqn4kquuru ; * izoy0sdbwz = 4
; } } break ; default : * izoy0sdbwz = 3 ; if ( ( ! ( lfbpfq3smd ( localDW )
!= 0.0 ) ) || ( b15g510lmm ( localDW ) != 0.0 ) ) { localDW -> mpaxivywwh =
aqn4kquuru ; * izoy0sdbwz = 4 ; } break ; } } } else { * izoy0sdbwz = 0 ; } }
void i2odqztc0a ( int8_T * meckanrj2q , int8_T * cpv2jbmc33 , int8_T *
jx1kwzmku0 , int8_T * izoy0sdbwz , ib3bykxihl * localDW ) { localDW ->
jxafxk4oqz = abe01fyzks ; localDW -> cbw25uwmwe = abe01fyzks ; localDW ->
oyi3pbwxsi = abe01fyzks ; localDW -> ji3tc4mchm = abe01fyzks ; localDW ->
hbaqu3tjvl = abe01fyzks ; localDW -> mpaxivywwh = abe01fyzks ; localDW ->
byk4it4mn4 = abe01fyzks ; localDW -> juzg2wjpep = abe01fyzks ; localDW ->
ase32ysxwz = 0U ; localDW -> kiqkxaskny = 0.0 ; localDW -> jrsv2du3ux = 0.0 ;
localDW -> ie42kl3foi = 0.0 ; localDW -> lsyrrqyfc3 = 0.0 ; localDW ->
luwfne0fze = 0.0 ; localDW -> p0zzmfdw2s = 0.0 ; localDW -> hxentl1cgi = 0.0
; localDW -> kuwjtglrmc = 0.0 ; localDW -> erd0rz1uuq = 0 ; localDW ->
j2mrqjospj = 0 ; localDW -> cwczkfsfwo = 0 ; localDW -> e5rzcmrkza = 0 ; *
meckanrj2q = 0 ; * cpv2jbmc33 = 0 ; * jx1kwzmku0 = 0 ; * izoy0sdbwz = 0 ; }
void p3royrfzsq ( int8_T * meckanrj2q , int8_T * cpv2jbmc33 , int8_T *
jx1kwzmku0 , int8_T * izoy0sdbwz , ib3bykxihl * localDW ) { localDW ->
jxafxk4oqz = abe01fyzks ; localDW -> cbw25uwmwe = abe01fyzks ; localDW ->
oyi3pbwxsi = abe01fyzks ; localDW -> ji3tc4mchm = abe01fyzks ; localDW ->
hbaqu3tjvl = abe01fyzks ; localDW -> mpaxivywwh = abe01fyzks ; localDW ->
byk4it4mn4 = abe01fyzks ; localDW -> juzg2wjpep = abe01fyzks ; localDW ->
ase32ysxwz = 0U ; localDW -> kiqkxaskny = 0.0 ; localDW -> jrsv2du3ux = 0.0 ;
localDW -> ie42kl3foi = 0.0 ; localDW -> lsyrrqyfc3 = 0.0 ; localDW ->
luwfne0fze = 0.0 ; localDW -> p0zzmfdw2s = 0.0 ; localDW -> hxentl1cgi = 0.0
; localDW -> kuwjtglrmc = 0.0 ; localDW -> erd0rz1uuq = 0 ; localDW ->
j2mrqjospj = 0 ; localDW -> cwczkfsfwo = 0 ; localDW -> e5rzcmrkza = 0 ; *
meckanrj2q = 0 ; * cpv2jbmc33 = 0 ; * jx1kwzmku0 = 0 ; * izoy0sdbwz = 0 ; }
void asbhl20_FDIRmodelogicApp ( const boolean_T hzccke5rmp [ 3 ] , const
boolean_T pfntoy3xkz [ 2 ] , const boolean_T hp0wqb1p3i [ 2 ] , int8_T *
meckanrj2q , int8_T * cpv2jbmc33 , int8_T * jx1kwzmku0 , int8_T * izoy0sdbwz
, ib3bykxihl * localDW ) { if ( localDW -> ase32ysxwz == 0U ) { localDW ->
ase32ysxwz = 1U ; ahth4hcu5q ( hzccke5rmp , hp0wqb1p3i , localDW ) ;
p12kfhtpp2 ( hzccke5rmp , pfntoy3xkz , localDW ) ; localDW -> erd0rz1uuq = 0
; localDW -> oyi3pbwxsi = dctdxp1phd ; localDW -> ji3tc4mchm = cv4vbtpbn3 ; *
meckanrj2q = 2 ; localDW -> j2mrqjospj = 0 ; localDW -> byk4it4mn4 =
dctdxp1phd ; localDW -> juzg2wjpep = cv4vbtpbn3 ; * jx1kwzmku0 = 2 ; localDW
-> cwczkfsfwo = 0 ; localDW -> jxafxk4oqz = dctdxp1phd ; localDW ->
cbw25uwmwe = cv4vbtpbn3 ; * cpv2jbmc33 = 2 ; localDW -> e5rzcmrkza = 0 ;
localDW -> hbaqu3tjvl = dctdxp1phd ; localDW -> mpaxivywwh = cv4vbtpbn3 ; *
izoy0sdbwz = 2 ; } else { celbwo0ozv ( hzccke5rmp , pfntoy3xkz , hp0wqb1p3i ,
meckanrj2q , cpv2jbmc33 , jx1kwzmku0 , izoy0sdbwz , localDW ) ; } } void
coixd5oata ( erjgiscrq5 * const jak0do2ew0 ) { if ( !
slIsRapidAcceleratorSimulating ( ) ) { slmrRunPluginEvent ( jak0do2ew0 ->
_mdlRefSfcnS , "asbhl20_FDIRmodelogicApp" ,
"SIMSTATUS_TERMINATING_MODELREF_ACCEL_EVENT" ) ; } } void o0xknv4kz2 (
SimStruct * _mdlRefSfcnS , int_T mdlref_TID0 , erjgiscrq5 * const jak0do2ew0
, ib3bykxihl * localDW , void * sysRanPtr , int contextTid ,
rtwCAPI_ModelMappingInfo * rt_ParentMMI , const char_T * rt_ChildPath , int_T
rt_ChildMMIIdx , int_T rt_CSTATEIdx ) { rt_InitInfAndNaN ( sizeof ( real_T )
) ; { ( void ) memset ( ( void * ) jak0do2ew0 , 0 , sizeof ( erjgiscrq5 ) ) ;
} jak0do2ew0 -> Timing . mdlref_GlobalTID [ 0 ] = mdlref_TID0 ; jak0do2ew0 ->
_mdlRefSfcnS = ( _mdlRefSfcnS ) ; if ( ! slIsRapidAcceleratorSimulating ( ) )
{ slmrRunPluginEvent ( jak0do2ew0 -> _mdlRefSfcnS ,
"asbhl20_FDIRmodelogicApp" , "START_OF_SIM_MODEL_MODELREF_ACCEL_EVENT" ) ; }
{ ( void ) memset ( ( void * ) localDW , 0 , sizeof ( ib3bykxihl ) ) ; }
localDW -> kiqkxaskny = 0.0 ; localDW -> jrsv2du3ux = 0.0 ; localDW ->
ie42kl3foi = 0.0 ; localDW -> lsyrrqyfc3 = 0.0 ; localDW -> luwfne0fze = 0.0
; localDW -> p0zzmfdw2s = 0.0 ; localDW -> hxentl1cgi = 0.0 ; localDW ->
kuwjtglrmc = 0.0 ; asbhl20_FDIRmodelogicApp_InitializeDataMapInfo (
jak0do2ew0 , localDW , sysRanPtr , contextTid ) ; if ( ( rt_ParentMMI != (
NULL ) ) && ( rt_ChildPath != ( NULL ) ) ) { rtwCAPI_SetChildMMI ( *
rt_ParentMMI , rt_ChildMMIIdx , & ( jak0do2ew0 -> DataMapInfo . mmi ) ) ;
rtwCAPI_SetPath ( jak0do2ew0 -> DataMapInfo . mmi , rt_ChildPath ) ;
rtwCAPI_MMISetContStateStartIndex ( jak0do2ew0 -> DataMapInfo . mmi ,
rt_CSTATEIdx ) ; } } void mr_asbhl20_FDIRmodelogicApp_MdlInfoRegFcn (
SimStruct * mdlRefSfcnS , char_T * modelName , int_T * retVal ) { * retVal =
0 ; { boolean_T regSubmodelsMdlinfo = false ; ssGetRegSubmodelsMdlinfo (
mdlRefSfcnS , & regSubmodelsMdlinfo ) ; if ( regSubmodelsMdlinfo ) { } } *
retVal = 0 ; ssRegModelRefMdlInfo ( mdlRefSfcnS , modelName ,
rtMdlInfo_asbhl20_FDIRmodelogicApp , 44 ) ; * retVal = 1 ; } static void
mr_asbhl20_FDIRmodelogicApp_cacheDataAsMxArray ( mxArray * destArray ,
mwIndex i , int j , const void * srcData , size_t numBytes ) ; static void
mr_asbhl20_FDIRmodelogicApp_cacheDataAsMxArray ( mxArray * destArray ,
mwIndex i , int j , const void * srcData , size_t numBytes ) { mxArray *
newArray = mxCreateUninitNumericMatrix ( ( size_t ) 1 , numBytes ,
mxUINT8_CLASS , mxREAL ) ; memcpy ( ( uint8_T * ) mxGetData ( newArray ) , (
const uint8_T * ) srcData , numBytes ) ; mxSetFieldByNumber ( destArray , i ,
j , newArray ) ; } static void
mr_asbhl20_FDIRmodelogicApp_restoreDataFromMxArray ( void * destData , const
mxArray * srcArray , mwIndex i , int j , size_t numBytes ) ; static void
mr_asbhl20_FDIRmodelogicApp_restoreDataFromMxArray ( void * destData , const
mxArray * srcArray , mwIndex i , int j , size_t numBytes ) { memcpy ( (
uint8_T * ) destData , ( const uint8_T * ) mxGetData ( mxGetFieldByNumber (
srcArray , i , j ) ) , numBytes ) ; } static void
mr_asbhl20_FDIRmodelogicApp_cacheBitFieldToMxArray ( mxArray * destArray ,
mwIndex i , int j , uint_T bitVal ) ; static void
mr_asbhl20_FDIRmodelogicApp_cacheBitFieldToMxArray ( mxArray * destArray ,
mwIndex i , int j , uint_T bitVal ) { mxSetFieldByNumber ( destArray , i , j
, mxCreateDoubleScalar ( ( double ) bitVal ) ) ; } static uint_T
mr_asbhl20_FDIRmodelogicApp_extractBitFieldFromMxArray ( const mxArray *
srcArray , mwIndex i , int j , uint_T numBits ) ; static uint_T
mr_asbhl20_FDIRmodelogicApp_extractBitFieldFromMxArray ( const mxArray *
srcArray , mwIndex i , int j , uint_T numBits ) { const uint_T varVal = (
uint_T ) mxGetScalar ( mxGetFieldByNumber ( srcArray , i , j ) ) ; return
varVal & ( ( 1u << numBits ) - 1u ) ; } static void
mr_asbhl20_FDIRmodelogicApp_cacheDataToMxArrayWithOffset ( mxArray *
destArray , mwIndex i , int j , mwIndex offset , const void * srcData ,
size_t numBytes ) ; static void
mr_asbhl20_FDIRmodelogicApp_cacheDataToMxArrayWithOffset ( mxArray *
destArray , mwIndex i , int j , mwIndex offset , const void * srcData ,
size_t numBytes ) { uint8_T * varData = ( uint8_T * ) mxGetData (
mxGetFieldByNumber ( destArray , i , j ) ) ; memcpy ( ( uint8_T * ) & varData
[ offset * numBytes ] , ( const uint8_T * ) srcData , numBytes ) ; } static
void mr_asbhl20_FDIRmodelogicApp_restoreDataFromMxArrayWithOffset ( void *
destData , const mxArray * srcArray , mwIndex i , int j , mwIndex offset ,
size_t numBytes ) ; static void
mr_asbhl20_FDIRmodelogicApp_restoreDataFromMxArrayWithOffset ( void *
destData , const mxArray * srcArray , mwIndex i , int j , mwIndex offset ,
size_t numBytes ) { const uint8_T * varData = ( const uint8_T * ) mxGetData (
mxGetFieldByNumber ( srcArray , i , j ) ) ; memcpy ( ( uint8_T * ) destData ,
( const uint8_T * ) & varData [ offset * numBytes ] , numBytes ) ; } static
void mr_asbhl20_FDIRmodelogicApp_cacheBitFieldToCellArrayWithOffset ( mxArray
* destArray , mwIndex i , int j , mwIndex offset , uint_T fieldVal ) ; static
void mr_asbhl20_FDIRmodelogicApp_cacheBitFieldToCellArrayWithOffset ( mxArray
* destArray , mwIndex i , int j , mwIndex offset , uint_T fieldVal ) {
mxSetCell ( mxGetFieldByNumber ( destArray , i , j ) , offset ,
mxCreateDoubleScalar ( ( double ) fieldVal ) ) ; } static uint_T
mr_asbhl20_FDIRmodelogicApp_extractBitFieldFromCellArrayWithOffset ( const
mxArray * srcArray , mwIndex i , int j , mwIndex offset , uint_T numBits ) ;
static uint_T
mr_asbhl20_FDIRmodelogicApp_extractBitFieldFromCellArrayWithOffset ( const
mxArray * srcArray , mwIndex i , int j , mwIndex offset , uint_T numBits ) {
const uint_T fieldVal = ( uint_T ) mxGetScalar ( mxGetCell (
mxGetFieldByNumber ( srcArray , i , j ) , offset ) ) ; return fieldVal & ( (
1u << numBits ) - 1u ) ; } mxArray * mr_asbhl20_FDIRmodelogicApp_GetDWork (
const apfjvdlacsv * mdlrefDW ) { static const char * ssDWFieldNames [ 3 ] = {
"NULL->rtb" , "rtdw" , "NULL->rtzce" , } ; mxArray * ssDW =
mxCreateStructMatrix ( 1 , 1 , 3 , ssDWFieldNames ) ; { static const char *
rtdwDataFieldNames [ 21 ] = { "mdlrefDW->rtdw.kiqkxaskny" ,
"mdlrefDW->rtdw.jrsv2du3ux" , "mdlrefDW->rtdw.ie42kl3foi" ,
"mdlrefDW->rtdw.lsyrrqyfc3" , "mdlrefDW->rtdw.luwfne0fze" ,
"mdlrefDW->rtdw.p0zzmfdw2s" , "mdlrefDW->rtdw.hxentl1cgi" ,
"mdlrefDW->rtdw.kuwjtglrmc" , "mdlrefDW->rtdw.erd0rz1uuq" ,
"mdlrefDW->rtdw.j2mrqjospj" , "mdlrefDW->rtdw.cwczkfsfwo" ,
"mdlrefDW->rtdw.e5rzcmrkza" , "mdlrefDW->rtdw.ase32ysxwz" ,
"mdlrefDW->rtdw.oyi3pbwxsi" , "mdlrefDW->rtdw.ji3tc4mchm" ,
"mdlrefDW->rtdw.byk4it4mn4" , "mdlrefDW->rtdw.juzg2wjpep" ,
"mdlrefDW->rtdw.jxafxk4oqz" , "mdlrefDW->rtdw.cbw25uwmwe" ,
"mdlrefDW->rtdw.hbaqu3tjvl" , "mdlrefDW->rtdw.mpaxivywwh" , } ; mxArray *
rtdwData = mxCreateStructMatrix ( 1 , 1 , 21 , rtdwDataFieldNames ) ;
mr_asbhl20_FDIRmodelogicApp_cacheDataAsMxArray ( rtdwData , 0 , 0 , & (
mdlrefDW -> rtdw . kiqkxaskny ) , sizeof ( mdlrefDW -> rtdw . kiqkxaskny ) )
; mr_asbhl20_FDIRmodelogicApp_cacheDataAsMxArray ( rtdwData , 0 , 1 , & (
mdlrefDW -> rtdw . jrsv2du3ux ) , sizeof ( mdlrefDW -> rtdw . jrsv2du3ux ) )
; mr_asbhl20_FDIRmodelogicApp_cacheDataAsMxArray ( rtdwData , 0 , 2 , & (
mdlrefDW -> rtdw . ie42kl3foi ) , sizeof ( mdlrefDW -> rtdw . ie42kl3foi ) )
; mr_asbhl20_FDIRmodelogicApp_cacheDataAsMxArray ( rtdwData , 0 , 3 , & (
mdlrefDW -> rtdw . lsyrrqyfc3 ) , sizeof ( mdlrefDW -> rtdw . lsyrrqyfc3 ) )
; mr_asbhl20_FDIRmodelogicApp_cacheDataAsMxArray ( rtdwData , 0 , 4 , & (
mdlrefDW -> rtdw . luwfne0fze ) , sizeof ( mdlrefDW -> rtdw . luwfne0fze ) )
; mr_asbhl20_FDIRmodelogicApp_cacheDataAsMxArray ( rtdwData , 0 , 5 , & (
mdlrefDW -> rtdw . p0zzmfdw2s ) , sizeof ( mdlrefDW -> rtdw . p0zzmfdw2s ) )
; mr_asbhl20_FDIRmodelogicApp_cacheDataAsMxArray ( rtdwData , 0 , 6 , & (
mdlrefDW -> rtdw . hxentl1cgi ) , sizeof ( mdlrefDW -> rtdw . hxentl1cgi ) )
; mr_asbhl20_FDIRmodelogicApp_cacheDataAsMxArray ( rtdwData , 0 , 7 , & (
mdlrefDW -> rtdw . kuwjtglrmc ) , sizeof ( mdlrefDW -> rtdw . kuwjtglrmc ) )
; mr_asbhl20_FDIRmodelogicApp_cacheDataAsMxArray ( rtdwData , 0 , 8 , & (
mdlrefDW -> rtdw . erd0rz1uuq ) , sizeof ( mdlrefDW -> rtdw . erd0rz1uuq ) )
; mr_asbhl20_FDIRmodelogicApp_cacheDataAsMxArray ( rtdwData , 0 , 9 , & (
mdlrefDW -> rtdw . j2mrqjospj ) , sizeof ( mdlrefDW -> rtdw . j2mrqjospj ) )
; mr_asbhl20_FDIRmodelogicApp_cacheDataAsMxArray ( rtdwData , 0 , 10 , & (
mdlrefDW -> rtdw . cwczkfsfwo ) , sizeof ( mdlrefDW -> rtdw . cwczkfsfwo ) )
; mr_asbhl20_FDIRmodelogicApp_cacheDataAsMxArray ( rtdwData , 0 , 11 , & (
mdlrefDW -> rtdw . e5rzcmrkza ) , sizeof ( mdlrefDW -> rtdw . e5rzcmrkza ) )
; mr_asbhl20_FDIRmodelogicApp_cacheDataAsMxArray ( rtdwData , 0 , 12 , & (
mdlrefDW -> rtdw . ase32ysxwz ) , sizeof ( mdlrefDW -> rtdw . ase32ysxwz ) )
; mr_asbhl20_FDIRmodelogicApp_cacheDataAsMxArray ( rtdwData , 0 , 13 , & (
mdlrefDW -> rtdw . oyi3pbwxsi ) , sizeof ( mdlrefDW -> rtdw . oyi3pbwxsi ) )
; mr_asbhl20_FDIRmodelogicApp_cacheDataAsMxArray ( rtdwData , 0 , 14 , & (
mdlrefDW -> rtdw . ji3tc4mchm ) , sizeof ( mdlrefDW -> rtdw . ji3tc4mchm ) )
; mr_asbhl20_FDIRmodelogicApp_cacheDataAsMxArray ( rtdwData , 0 , 15 , & (
mdlrefDW -> rtdw . byk4it4mn4 ) , sizeof ( mdlrefDW -> rtdw . byk4it4mn4 ) )
; mr_asbhl20_FDIRmodelogicApp_cacheDataAsMxArray ( rtdwData , 0 , 16 , & (
mdlrefDW -> rtdw . juzg2wjpep ) , sizeof ( mdlrefDW -> rtdw . juzg2wjpep ) )
; mr_asbhl20_FDIRmodelogicApp_cacheDataAsMxArray ( rtdwData , 0 , 17 , & (
mdlrefDW -> rtdw . jxafxk4oqz ) , sizeof ( mdlrefDW -> rtdw . jxafxk4oqz ) )
; mr_asbhl20_FDIRmodelogicApp_cacheDataAsMxArray ( rtdwData , 0 , 18 , & (
mdlrefDW -> rtdw . cbw25uwmwe ) , sizeof ( mdlrefDW -> rtdw . cbw25uwmwe ) )
; mr_asbhl20_FDIRmodelogicApp_cacheDataAsMxArray ( rtdwData , 0 , 19 , & (
mdlrefDW -> rtdw . hbaqu3tjvl ) , sizeof ( mdlrefDW -> rtdw . hbaqu3tjvl ) )
; mr_asbhl20_FDIRmodelogicApp_cacheDataAsMxArray ( rtdwData , 0 , 20 , & (
mdlrefDW -> rtdw . mpaxivywwh ) , sizeof ( mdlrefDW -> rtdw . mpaxivywwh ) )
; mxSetFieldByNumber ( ssDW , 0 , 1 , rtdwData ) ; } return ssDW ; } void
mr_asbhl20_FDIRmodelogicApp_SetDWork ( apfjvdlacsv * mdlrefDW , const mxArray
* ssDW ) { { const mxArray * rtdwData = mxGetFieldByNumber ( ssDW , 0 , 1 ) ;
mr_asbhl20_FDIRmodelogicApp_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw .
kiqkxaskny ) , rtdwData , 0 , 0 , sizeof ( mdlrefDW -> rtdw . kiqkxaskny ) )
; mr_asbhl20_FDIRmodelogicApp_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw .
jrsv2du3ux ) , rtdwData , 0 , 1 , sizeof ( mdlrefDW -> rtdw . jrsv2du3ux ) )
; mr_asbhl20_FDIRmodelogicApp_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw .
ie42kl3foi ) , rtdwData , 0 , 2 , sizeof ( mdlrefDW -> rtdw . ie42kl3foi ) )
; mr_asbhl20_FDIRmodelogicApp_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw .
lsyrrqyfc3 ) , rtdwData , 0 , 3 , sizeof ( mdlrefDW -> rtdw . lsyrrqyfc3 ) )
; mr_asbhl20_FDIRmodelogicApp_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw .
luwfne0fze ) , rtdwData , 0 , 4 , sizeof ( mdlrefDW -> rtdw . luwfne0fze ) )
; mr_asbhl20_FDIRmodelogicApp_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw .
p0zzmfdw2s ) , rtdwData , 0 , 5 , sizeof ( mdlrefDW -> rtdw . p0zzmfdw2s ) )
; mr_asbhl20_FDIRmodelogicApp_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw .
hxentl1cgi ) , rtdwData , 0 , 6 , sizeof ( mdlrefDW -> rtdw . hxentl1cgi ) )
; mr_asbhl20_FDIRmodelogicApp_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw .
kuwjtglrmc ) , rtdwData , 0 , 7 , sizeof ( mdlrefDW -> rtdw . kuwjtglrmc ) )
; mr_asbhl20_FDIRmodelogicApp_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw .
erd0rz1uuq ) , rtdwData , 0 , 8 , sizeof ( mdlrefDW -> rtdw . erd0rz1uuq ) )
; mr_asbhl20_FDIRmodelogicApp_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw .
j2mrqjospj ) , rtdwData , 0 , 9 , sizeof ( mdlrefDW -> rtdw . j2mrqjospj ) )
; mr_asbhl20_FDIRmodelogicApp_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw .
cwczkfsfwo ) , rtdwData , 0 , 10 , sizeof ( mdlrefDW -> rtdw . cwczkfsfwo ) )
; mr_asbhl20_FDIRmodelogicApp_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw .
e5rzcmrkza ) , rtdwData , 0 , 11 , sizeof ( mdlrefDW -> rtdw . e5rzcmrkza ) )
; mr_asbhl20_FDIRmodelogicApp_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw .
ase32ysxwz ) , rtdwData , 0 , 12 , sizeof ( mdlrefDW -> rtdw . ase32ysxwz ) )
; mr_asbhl20_FDIRmodelogicApp_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw .
oyi3pbwxsi ) , rtdwData , 0 , 13 , sizeof ( mdlrefDW -> rtdw . oyi3pbwxsi ) )
; mr_asbhl20_FDIRmodelogicApp_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw .
ji3tc4mchm ) , rtdwData , 0 , 14 , sizeof ( mdlrefDW -> rtdw . ji3tc4mchm ) )
; mr_asbhl20_FDIRmodelogicApp_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw .
byk4it4mn4 ) , rtdwData , 0 , 15 , sizeof ( mdlrefDW -> rtdw . byk4it4mn4 ) )
; mr_asbhl20_FDIRmodelogicApp_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw .
juzg2wjpep ) , rtdwData , 0 , 16 , sizeof ( mdlrefDW -> rtdw . juzg2wjpep ) )
; mr_asbhl20_FDIRmodelogicApp_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw .
jxafxk4oqz ) , rtdwData , 0 , 17 , sizeof ( mdlrefDW -> rtdw . jxafxk4oqz ) )
; mr_asbhl20_FDIRmodelogicApp_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw .
cbw25uwmwe ) , rtdwData , 0 , 18 , sizeof ( mdlrefDW -> rtdw . cbw25uwmwe ) )
; mr_asbhl20_FDIRmodelogicApp_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw .
hbaqu3tjvl ) , rtdwData , 0 , 19 , sizeof ( mdlrefDW -> rtdw . hbaqu3tjvl ) )
; mr_asbhl20_FDIRmodelogicApp_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw .
mpaxivywwh ) , rtdwData , 0 , 20 , sizeof ( mdlrefDW -> rtdw . mpaxivywwh ) )
; } } void mr_asbhl20_FDIRmodelogicApp_RegisterSimStateChecksum ( SimStruct *
S ) { const uint32_T chksum [ 4 ] = { 677273164U , 3407314787U , 216385060U ,
495720886U , } ; slmrModelRefRegisterSimStateChecksum ( S ,
"asbhl20_FDIRmodelogicApp" , & chksum [ 0 ] ) ; } mxArray *
mr_asbhl20_FDIRmodelogicApp_GetSimStateDisallowedBlocks ( ) { return NULL ; }
