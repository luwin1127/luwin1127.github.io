#include "__cf_asbhl20_FDIRmodelogicApp.h"
#ifndef RTW_HEADER_asbhl20_FDIRmodelogicApp_capi_h_
#define RTW_HEADER_asbhl20_FDIRmodelogicApp_capi_h_
#include "asbhl20_FDIRmodelogicApp.h"
extern void asbhl20_FDIRmodelogicApp_InitializeDataMapInfo ( erjgiscrq5 *
const jak0do2ew0 , ib3bykxihl * localDW , void * sysRanPtr , int contextTid )
;
#endif
