#include "__cf_asbhl20_FDIRmodelogicApp.h"
#ifndef RTW_HEADER_asbhl20_FDIRmodelogicApp_cap_host_h_
#define RTW_HEADER_asbhl20_FDIRmodelogicApp_cap_host_h_
#ifdef HOST_CAPI_BUILD
#include "rtw_capi.h"
#include "rtw_modelmap.h"
typedef struct { rtwCAPI_ModelMappingInfo mmi ; }
asbhl20_FDIRmodelogicApp_host_DataMapInfo_T ;
#ifdef __cplusplus
extern "C" {
#endif
void asbhl20_FDIRmodelogicApp_host_InitializeDataMapInfo (
asbhl20_FDIRmodelogicApp_host_DataMapInfo_T * dataMap , const char * path ) ;
#ifdef __cplusplus
}
#endif
#endif
#endif
